package com.colloboration.chatapp.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.colloboration.chatapp.model.Blog;
import com.colloboration.chatapp.model.ChatUser;
import com.colloboration.chatapp.service.BlogService;
import com.colloboration.chatapp.service.ChatuserService;

@Controller
public class BlogController {

	@Autowired
	BlogService bs;

	@Autowired
	ChatuserService cs;

	@ModelAttribute("command")
	public Blog construct() {
		return new Blog();
	}

	@RequestMapping("/addBlog")
	public ModelAndView Blog() {

		System.out.println("in add blog get ");
		return new ModelAndView("Postinblog");

	}

	@ModelAttribute("allDepartments")
	public List<String> populateDepartments() {
		List<String> l = new ArrayList<String>();
		l.add("It");
		l.add("Gniit");
		l.add("java");
		l.add("dotnet");
		return l;
	}

	@RequestMapping(value = "postBlog", method = RequestMethod.POST)
	public ModelAndView addBlog(HttpServletRequest req, @ModelAttribute("command") Blog bl, BindingResult result) {

		ModelAndView mv = new ModelAndView("Postinblog");
		String returnvalue = null, fileName = null, npath = null;

		if (result.hasErrors()) {
			System.out.println("in add blog post -err");
			returnvalue = "Errrrrrrrr!!!!!! sorry try again, BuDdY!!!";
		}

		else {

			System.out.println("in add blog post - succ");
			// bl.setBlog_category("It");
			ServletContext sctx = req.getServletContext();
			String p = sctx.getRealPath("/");
			MultipartFile file1 = bl.getM1();
			if (!file1.isEmpty()) {
				try {

					fileName = file1.getOriginalFilename();
					byte[] bytes = file1.getBytes();
					npath = p + "\\resources\\images\\blog\\" + fileName;
					System.out.println(npath);
					// String npath="/App/reources/"+fileName;
					BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(new File(npath)));
					buffStream.write(bytes);
					buffStream.close();
					String dbfilename = "/resources/images/blog/" + fileName;

					bl.setDbpath(dbfilename);
					bl.setBlogcount(1);
					bl.setPosted_time(new java.util.Date());
					bl.setPosted_date(new java.util.Date());
					List<ChatUser> css = cs.getUserbyName_forId();
					System.out.println("in add blog post - succ - " + css.get(0).getUsername());
					bl.setChusr(css.get(0));
					bs.addBlog(bl);
					returnvalue = "Succesfully posted";
				}

				catch (Exception e) {

				}

			}
		}
		mv.addObject("msg", returnvalue);
		return mv;

	}

	@RequestMapping(value = "blogscatergory", method = RequestMethod.GET)
	public String getblogcategorylink() {

		return "Blogscategory";
	}
	@RequestMapping(value="viewmyblog",method = RequestMethod.GET)
	public List<Blog> getmyblog()
	{
	System.out.println("in get blog user by name get method from ang ctlr");	
		List<Blog> l=new ArrayList<Blog>();
		l=bs.getAllBlogsbyname();
		return l;
	}
	@RequestMapping("getmyblog")
	public String getmyb(){
	return "displayBlog";
	}
}
