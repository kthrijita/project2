package com.colloboration.chatapp.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.web.multipart.MultipartFile;




@Entity
public class Blog {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int blogId;
	private String message;
	@Temporal(TemporalType.TIME)
	//@DateTimeFormat("dd.MM HH:mm") //this is for display and parsing, not storage
	//@DateTimeFormat(pattern="dd.MM.yyyy HH:mm")
	private Date posted_time;
	@Temporal(TemporalType.DATE)
	private Date posted_date;
	private int blogcount;
	private String blog_category;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userId")
	private ChatUser chusr;
	private transient String temppath;
	private String dbpath;
	private transient MultipartFile m1;
	
	
	public String getDbpath() {
		return dbpath;
	}
	public void setDbpath(String dbpath) {
		this.dbpath = dbpath;
	}
	public String getTemppath() {
		return temppath;
	}
	public void setM1(MultipartFile m1) {
		this.m1 = m1;
	}
	
	public MultipartFile getM1() {
		return m1;
	}
	public void setTemppath(String temppath) {
		this.temppath = temppath;
	}
	public Date getPosted_time() {
		return posted_time;
	}
	public void setPosted_time(Date posted_time) {
		this.posted_time = posted_time;
	}
	private String tags;
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	
	public int getBlogId() {
		return blogId;
	}
	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getPosted_date() {
		
		return posted_date;
	}
	public void setPosted_date(Date posted_date) {
		
		this.posted_date = posted_date;
	}
	public int getBlogcount() {
		return blogcount;
	}
	public void setBlogcount(int blogcount) {
		this.blogcount = blogcount;
	}
	public String getBlog_category() {
		return blog_category;
	}
	public void setBlog_category(String blog_category) {
		this.blog_category = blog_category;
	}
	public ChatUser getChusr() {
		return chusr;
	}
	public void setChusr(ChatUser chusr) {
		this.chusr = chusr;
	}
	
	
	
}
