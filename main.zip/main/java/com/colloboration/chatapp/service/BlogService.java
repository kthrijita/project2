package com.colloboration.chatapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.colloboration.chatapp.dao.Blogdao;
import com.colloboration.chatapp.dao.ChatuserDao;
import com.colloboration.chatapp.model.Blog;
import com.colloboration.chatapp.model.ChatUser;

@Service
public class BlogService {
 
	@Autowired	
    private ChatuserDao chd;
	@Autowired	
    private Blogdao bs;
	
	@Transactional
	public void addBlog(Blog usr) {
		System.out.println("in blog service - service - addblogs");
		bs.addBlog(usr);
	}
	@Transactional
	public List<Blog> getAllBlogs() {
		System.out.println("in chat user - service - get all user");
		List<Blog> l=bs.getAllBlog();
		return l;
	}
	
	public List<Blog> getAllBlogsbyname(){
		
		return  bs.getAllBlogsbyname();
		
	}
}
