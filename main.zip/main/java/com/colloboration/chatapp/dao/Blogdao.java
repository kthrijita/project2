package com.colloboration.chatapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.colloboration.chatapp.model.Blog;
import com.colloboration.chatapp.model.ChatUser;

@Repository
public class Blogdao {

	@Autowired(required = true)
	private SessionFactory sf;
	@Autowired
	private ChatuserDao cd;

	@Transactional
	public void addBlog(Blog usr) {
		System.out.println("in chat user - dao - add user " + usr);
		sf.getCurrentSession().save(usr);

	}

	@Transactional
	public List<Blog> getAllBlog() {
		System.out.println("in chat user - dao - get all user ");

		List<Blog> l = sf.getCurrentSession().createQuery("from Blog").list();

		// t.commit();
		System.out.println("---- in all prod" + l.get(0));

		return l;
	}
	public List<Blog> getAllBlogsbyname(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	      String name = auth.getName();
	      System.out.println("in get all blog by name "+name);
	      List<ChatUser> liuser=cd.getUserbyName_forId(name);
			//c.add(Restrictions.eq("mailId",g));
	      String userid=liuser.get(0).getUserId();
	      System.out.println("in get all blog by name_id for it "+userid);
	      Query q= sf.openSession().createQuery("from Blog where userid='"+userid+"'");
			
			List<Blog> l=q.list();
			return l;
	}
	
}
